
import logging
import shutil
import time
import pendulum
import json
import pickle
from datetime import datetime
from airflow import DAG
from airflow.operators.python_operator import PythonVirtualenvOperator
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.python_operator import BranchPythonOperator
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import log_loss
from sklearn.metrics import roc_auc_score
from sklearn.metrics import f1_score
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from tools import DataPreprocessingModel1_v1


with DAG(
    'train_model1_v1',
    default_args={'retries': 0},
    description='Train model 1 version 1',
    schedule_interval=None,
    start_date=pendulum.datetime(2021, 1, 1, tz="UTC"),
    catchup=False,
    tags=['example'],
) as dag:
    
    def split_dataset():
        
        df = pd.read_csv("/data/PS_20174392719_1491204439457_log.csv", sep=',')

        print(df.shape)
        print(df.columns)
        
        # Split
        X_train, X_valid, y_train, y_valid = train_test_split(df.drop(["isFraud"], axis = 1), 
                                                    df["isFraud"], 
                                                    train_size = 0.8, 
                                                    stratify = df["isFraud"])

        #Save data in tmp folder
        X_train.to_csv('/tmpdata/xtrain.csv', sep=';', index=False)
        y_train.to_csv('/tmpdata/ytrain.csv', sep=';', index=False)
        X_valid.to_csv('/tmpdata/xvalid.csv', sep=';', index=False)
        y_valid.to_csv('/tmpdata/yvalid.csv', sep=';', index=False)

        print('----------------------------')

    def train_model1_v1():

        # read data
        X_train = pd.read_csv('/tmpdata/xtrain.csv', sep=';')
        y_train = pd.read_csv('/tmpdata/ytrain.csv', sep=';')
        X_valid = pd.read_csv('/tmpdata/xvalid.csv', sep=';')
        y_valid = pd.read_csv('/tmpdata/yvalid.csv', sep=';')
        
        #Preprocessing
        X_train = DataPreprocessingModel1_v1(X_train)
        X_valid = DataPreprocessingModel1_v1(X_valid)

        print(X_train.columns)

        # Classifier
        clf = Pipeline(steps=[("scaler", MinMaxScaler()),
                              ("classifier", LogisticRegression(class_weight = {1 : 100, 0:1}))
                             ]
                    )

        clf.fit(X_train, y_train)

        # Predict
        y_pred = clf.predict(X_valid)

        # Evaluate
        f1 = f1_score(y_valid, y_pred, average="weighted")
        print("F1 :%.3f"  %(f1))
        
        # save model weights
        today_str = datetime.today().strftime('%Y%m%d')
        pickle_name = "/weights/model1_v1_" + today_str + ".pkl" 
        pickle.dump(clf, open(pickle_name, 'wb'))    

        return f1, pickle_name, today_str
   

    def check_metrics(**kwargs):
        """
        Branch
        """
        ti = kwargs['ti']
        f1, pickle_name, today_str = ti.xcom_pull(task_ids = 'train_model1_v1')

        ti.xcom_push(key ='pickle_name', value = pickle_name)
        ti.xcom_push(key ='today_str', value = today_str)
        
        if (f1 < 0.7) :
            return 'metrics_bad'
        else:
            return 'metrics_good'        

    def metrics_good(**kwargs):
        """
        Send email (emulation)
        """
        ti = kwargs['ti']
        f1, pickle_name, today_str = ti.xcom_pull(task_ids = 'train_model1_v1')
        print("F1 :%.3f"  %(f1))


    def metrics_bad():
        """
        Send email (emulation)
        """
        print("Alert!!!")        


    split_dataset_task = PythonOperator(
        task_id='split_dataset',
        python_callable=split_dataset,
    )

    train_model1_v1_task = PythonOperator(
        task_id='train_model1_v1',
        python_callable=train_model1_v1,
        provide_context=True
        )

    check_metrics_task = BranchPythonOperator(
        task_id='check_metrics',
        python_callable=check_metrics,
        provide_context=True
    )

    metrics_good_task = PythonOperator(
        task_id='metrics_good',
        python_callable=metrics_good,
        provide_context=True
    )    

    metrics_bad_task = PythonOperator(
        task_id='metrics_bad',
        python_callable=metrics_bad
    )        

    model_constructor_task = BashOperator(
        task_id='model_constructor',
        bash_command='mkdir -p /models/model1_v1_{{ti.xcom_pull(task_ids="check_metrics", key="today_str")}} &&'
            'rm -r /models/model1_v1_{{ti.xcom_pull(task_ids="check_metrics", key="today_str")}} &&'
            'rsync -a /models/model1_v1_etalon/ /models/model1_v1_{{ti.xcom_pull(task_ids="check_metrics", key="today_str")}} &&'
            'cp {{ti.xcom_pull(task_ids="check_metrics", key="pickle_name")}} /models/model1_v1_{{ti.xcom_pull(task_ids="check_metrics", key="today_str")}}/model1_v1.pkl'
    )

    split_dataset_task >> train_model1_v1_task >> check_metrics_task
    check_metrics_task >> metrics_good_task >> model_constructor_task
    check_metrics_task >> metrics_bad_task