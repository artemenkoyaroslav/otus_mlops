import pandas as pd

def DataPreprocessingModel1_v1(df_in):
    """
    Some data preprocessing (row level)
    Return DataFrame
    """    
    
    tmp_cols = ['type', 'newbalanceOrig', 'oldbalanceOrg', 'newbalanceDest', 'oldbalanceDest', 'amount']
    
    df_out = df_in[tmp_cols].copy()
    
    # подозрительные переводы
    df_out.loc[(df_out["type"] == "TRANSFER") & 
               (df_out["newbalanceOrig"] == 0) & 
               (df_out["oldbalanceOrg"] == df_out["amount"]), 
               'is_suspicious_transfer'] = 1

    df_out['is_suspicious_transfer'] = df_out['is_suspicious_transfer'].fillna(0).astype('int')
    
    # подозрительный вывод кэша
    df_out.loc[(df_out["type"] == "CASH_OUT") & 
               (df_out["newbalanceOrig"] == 0) & 
               (df_out["oldbalanceOrg"] == df_out["amount"]), 
               'is_suspicious_cash_out'] = 1    
    
    df_out['is_suspicious_cash_out'] = df_out['is_suspicious_cash_out'].fillna(0).astype('int')    
 
    # изменение баланса customer
    df_out['customer_balance_chng'] = df_out['oldbalanceOrg'] - df_out['newbalanceOrig']

    # изменение баланса recipient
    df_out['recipient_balance_chng'] = df_out['oldbalanceDest'] - df_out['newbalanceDest']
    
    for ttype in ['CASH_OUT', 'PAYMENT', 'CASH_IN', 'TRANSFER', 'DEBIT']:#df_out['type'].unique().tolist():
        df_out.loc[(df_out["type"] == ttype), ttype + '_amount'] = df_out['amount']
        df_out[ttype + '_amount'] = df_out[ttype + '_amount'].fillna(0)
        
    
    df_out.drop(tmp_cols, axis = 1, inplace = True)

    return df_out    