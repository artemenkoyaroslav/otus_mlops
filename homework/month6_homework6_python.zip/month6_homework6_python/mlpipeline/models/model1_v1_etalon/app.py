#from flask import Flask
from flask import Flask,jsonify,request
import pandas as pd
import numpy as np
import json
import pickle
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from typing import Dict, Tuple
from tools import DataPreprocessingModel1_v1


app = Flask('app')

@app.route("/")
def hello():

    return "Hello World!"

@app.route("/health")
def health() -> Tuple[Dict[str, str], int]:
    return {"health_status": "running"}, 200   

@app.route("/predict", methods = ['POST'])
def predict() -> Tuple[Dict[str, str], int]:
    
    request_data = request.get_json()

    df = pd.read_json(request_data, orient='split')

    X = DataPreprocessingModel1_v1(df)

    df_out = pd.DataFrame(clf.predict(X), columns = ['predict'])
  
    return (df_out.to_json(orient='split'), 200)

if __name__ == "__main__":
    clf = pickle.load(open('model1_v1.pkl', 'rb'))
    app.run(port=8081, host="0.0.0.0")